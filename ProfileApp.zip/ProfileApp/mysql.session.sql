create database profile;

use profile;

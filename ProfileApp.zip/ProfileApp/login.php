<?php
include 'navigation/nav.php';
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
require_once "include/login.inc.php";

if($_SERVER["REQUEST_METHOD"]== "POST"){
    $username = $_POST["username"];
    $pwd = $_POST["pwd"];

    if(empty($username) or empty($pwd)){
        $_SESSION['error'] = "Please fill in all fields!";
        header("Location: index.php");
        exit();
    }

    // Call the loginUser function
    $result = loginUser($username, $pwd);

    if ($result) {
        // If login is successful
        $_SESSION['loggedin'] = true;
        $_SESSION['username'] = $username; // Store the user's name in a session variable
        $_SESSION['pwd']= $pwd;
        header("location: home.php");
        exit();
    } else {
        // If login failed, show an error message
        $_SESSION['error'] = "Invalid username or password.";
        header("Location: index.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Login </title>
</head>
<body>
<div class="container">
    <h1 class="text-center" style="margin-top:30px;">Login</h1>
    <hr>
</div>

<form method="POST" action="login.php">
                        <div>
                            <label for="username">Username</label>
                            <input type="username" id="username" name="username" value="<?php echo (isset($_SESSION['username'])) ? $_SESSION['username'] : '';
                             unset($_SESSION['username']) ?>" placeholder="Input username" required>
                        </div>
                        <div>
                            <label for="pwd">Password</label>
                            <input type="password" id="pwd" name="pwd" value="<?php echo (isset($_SESSION['password'])) ? $_SESSION['password'] : '';
                             unset($_SESSION['password']) ?>" placeholder="Input password" required>
                        </div>
                        <hr>
                        <div>
                            <button type="submit" name="login">Login</button>
                            <a href="index.php">Register</a>
                        </div>
                    </form>
        <!-- <form method="POST" action="login.php">
            <div class="mb-3 row">
                <label for="username" class="col-sm-3 col-form-label">username</label>
                    <input class="form-control" type="username" id="username" name="username" value="<?php echo (isset($_SESSION['username'])) ? $_SESSION['username'] : ''; unset($_SESSION['username']) ?>" placeholder="input username" required>
                </div>
            </div>
            <div class="mb-3 row">
                <label for="pwd" class="col-sm-3 col-form-label">password</label>
                    <input class="form-control" type="pwd" id="pwd" name="pwd" value="<?php echo (isset($_SESSION['password'])) ? $_SESSION['password'] : ''; unset($_SESSION['password']) ?>" placeholder="input pwd" required>
                </div>
            </div>
        <hr>
        <div>
            <button type="submit" class="btn btn-success" name="Login"><i class="far fa-user"></i> Login</button>
        </div>
        </form> -->
    </div>
</div>
</body>
</html>

<footer>
    <div class="footer">
        <p>&copy; 2023 ProfielPlus. Alle rechten voorbehouden.</p>
        <p><a href="mailto:info@profielplus.com">info@profielplus.com</a></p>
    </div>
</footer>
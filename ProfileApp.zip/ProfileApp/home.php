<?php
include 'navigation/nav.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Home</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <header class="header">
        <!--<img src="./img/logo-no-background.png" alt="Logo" class="background-home">
      
    </header>
    -->
    </div>
    </header>
    <title>KEEP</title>
</head>

<body>

<?php
session_start();

if (isset($_SESSION['username'])) {
    echo "Welcome, " . htmlspecialchars($_SESSION['username']) . "!";
} else {
    // Redirect to login page or show a different message
    echo "Please log in.";
}
?>

<h1> Welcome to your profile <h1>

</body>

</html>
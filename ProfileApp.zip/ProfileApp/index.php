


<?php session_start(); 

include 'navigation/nav.php';
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title></title>
    <style>
        /* Add your CSS here */
    </style>
</head>
<body>
<div>
    <h1 style="text-align:center; margin-top:30px;">Register Here!</h1>

    <div>
        <div>
            <?php
                if(isset($_SESSION['error'])){
                    echo "
                        <div>
                            <i class='fas fa-exclamation-triangle'></i> ".$_SESSION['error']."
                        </div>
                    ";
  
                    //unset error
                    unset($_SESSION['error']);
                }
  
                if(isset($_SESSION['success'])){
                    echo "
                        <div>
                            <i class='fas fa-check-circle'></i> ".$_SESSION['success']."
                        </div>
                    ";
  
                    //unset success
                    unset($_SESSION['success']);
                }
            ?>
            <div>
                <div>
                        <form method="POST" action="include/register.inc.php">
                        <div>
                            <label for="username">Username</label>
                            <input type="username" id="username" name="username" value="<?php echo (isset($_SESSION['username'])) ? $_SESSION['username'] : '';
                            unset($_SESSION['username']) ?>" placeholder="username" required>
                        </div>
                        <div>
                            <label for="pwd">Password</label>
                            <input type="password" id="pwd" name="pwd" value="<?php echo (isset($_SESSION['pwd'])) ? $_SESSION['pwd'] : '';
                            unset($_SESSION['pwd']) ?>" placeholder=" password" required>
                        </div>
                        <div>
                            <label for="pwd_confirm">Confirm Password</label>
                            <input type="password" id="pwd_confirm" name="pwd_confirm" value="<?php echo (isset($_SESSION['pwd_confirm'])) ? $_SESSION['pwd_confirm'] : '';
                            unset($_SESSION['pwd_confirm']) ?>" placeholder="confirm password">
                        </div>
                        <hr>
                        <div>
                            <button type="submit" name="register">Signup</button>
                            <a href="login.php">Back to login</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>

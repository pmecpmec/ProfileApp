<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <?php
  require 'navigation/nav.php';
  ?>
  <br>
  <button class="back-btn">
    <span>Go back</span>
  </button>
</head>

<body>
  <a class="profileSettings" href="profile.php">Profile Settings</a>
  <br>
  <a class="loginSecurity" href="loginSecurity.php">Login & Security</a>
</body>

</html>
<link rel="stylesheet" type="text/css" href="style.css">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>About Me</title>
<header class="header">
  <div id="header" style="width:100% ;">
    <nav class="navigation">
      <img src="./img/logo-no-background.png" class="header-logo" alt="Logo">
      <center>
      <!--  The href attribute specifies the URL that the link should navigate to when clicked. -->
        <ul>
          <li><a href="login.php"><button>login</button></a></li>
          <li><a href="index.php"><button>register</button></a></li>
          <li><a href="home.php"><button>Home</button></a></li>
          <li><a href="education.php"><button>education</button></a></li>
          <li><a href="hobby.php"><button>My hobby</button></a></li>
          <li><a href="work.php"><button>My Work</button></a></li>
          <li><a href="settings.php"><button>settings</button></a>
          <li><a href="Logout.php"><button>log out</button></a>
         


          </li>
        </ul>
      </center>
    </nav>
  </div>
</header>

</html>